export class User {
    id:number;
    active:boolean;
    contact_number:string;
    firstname:string;
    lastname:string;
    password:string;
    reg_code:string;
    reg_datetime:string;
    username:string;
}
