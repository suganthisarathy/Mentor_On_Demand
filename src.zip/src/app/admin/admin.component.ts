import { Component, OnInit } from '@angular/core';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  admin:Admin;
  admin1:Admin;
  username:string;
  password:string;

  constructor(private adminService:AdminService) { }

  ngOnInit() {
  }

  onSubmit(){
    console.log("submit admin")
      this.adminService.AdminDetails(this.username,this.password)
         .subscribe((data:Admin)=>{console.log(data)
        this.createUser(data)});
      
  }

  createUser(data:Admin){
    this.admin1=data;
    window.localStorage.setItem("admin",this.admin1.username);
  }


}
