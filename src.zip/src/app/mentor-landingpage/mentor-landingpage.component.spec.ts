import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorLandingpageComponent } from './mentor-landingpage.component';

describe('MentorLandingpageComponent', () => {
  let component: MentorLandingpageComponent;
  let fixture: ComponentFixture<MentorLandingpageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorLandingpageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorLandingpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
